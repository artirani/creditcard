import React from 'react';
import './App.css';
import CreditCard from './components/CreditCard'
import Header from './components/Header'

class App extends React.Component{
  render(){
    return(
      <div>
      <Header/>
    <CreditCard/>
    </div>
    );
  }
}

export default App;
