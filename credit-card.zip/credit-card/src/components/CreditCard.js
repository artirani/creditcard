import React from 'react'
import MyInput from './MyInput'

class CreditCard extends React.Component{  

    render(){
     return   <div>
         CreditCard
         <MyInput/>
     </div>
       
    }
}

export default CreditCard